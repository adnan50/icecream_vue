▪        We have received your reservation. To confirm your it, kindly add us and send us a message on Kakaotalk: kakao id
▪        예약되었습니다. 레벨테스트 수업을 위한 수업환경 간단한 환경점검이 필요합니다. 고객 센터로(010 – 7797- 8136) 연락 주시거나 카톡 아이디 ‘아이스크림 잉글리쉬’로 상담요청 바랍니다. 임시
