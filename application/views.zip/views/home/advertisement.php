<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0058)http://www.xn-%2Doh5bnfxdy38aa.com/m7/notifyBoardList.view -->
<html><script async="" src="assets/faq_css/analytics.js.download"></script><script type="text/javascript" charset="utf-8" id="zm-extension" src="chrome-extension://fdcgdnkidjaadafnichfpabhfomcebme/scripts/webrtc-patch.js" async=""></script><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta http-equiv="Content-Style-Type" content="text/css">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">



<link href="<?php echo base_url() ?>assets/faq_css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url() ?>assets/faq_css/jquery-ui-1.9.2.custom.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/faq_css/font-awesome.min.css">
<link href="<?php echo base_url() ?>assets/faq_css/common.css" rel="stylesheet">
<script src="<?php echo base_url() ?>assets/faq_css/jquery-1.9.1.js.download"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/faq_css/jquery.banner.js.download"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/faq_css/jquery.preload.min.js.download"></script> 
<script src="<?php echo base_url() ?>assets/faq_css/jquery-ui.js.download"></script>
<script src="<?php echo base_url() ?>assets/faq_css/bootstrap.js.download"></script>
<script src="<?php echo base_url() ?>assets/faq_css/common.js.download"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/faq_css/match.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/faq_css/popup.css">
<script src="<?php echo base_url() ?>assets/faq_css/scheduleCell.js.download"></script>
<link href="<?php echo base_url() ?>assets/faq_css/common(1).css" rel="stylesheet" type="text/css"> 
<script src="<?php echo base_url() ?>assets/faq_css/json2.js.download"></script>
<link href='<?php echo base_url() ?>assets/apps/css/stylesheet.min.css' id='stylesheet-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url() ?>assets/apps/css/style_dynamic.css' id='style_dynamic-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url() ?>assets/apps/css/responsive.min.css' id='responsive-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url() ?>assets/apps/css/style_dynamic_responsive.css' id='style_dynamic_responsive-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url() ?>assets/apps/css/js_composer.min.css' id='js_composer_front-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url() ?>assets/apps/css/custom_css.css' id='custom_css-css' media='all' rel='stylesheet' type='text/css'>

<script src='<?php echo base_url() ?>assets/apps/scripts/jquery1.js' type='text/javascript'>
</script>
<script language="javascript" type="text/javascript">

function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>

<script>

	function makeUrl(url) {
		var index = url.indexOf('?');
		if (index == -1) {
			url = url + '?stamp=' + Date.now();
		} else {
			url = url + '&stamp=' + Date.now();
		}
		return url;
	}
</script>
<style type="text/css">
	
	@font-face {
  font-family: Typo_DodamM;
  src: url('public_html/portal/assets/fonts/Typo_DodamM.ttf');
}
body{font-family: Typo_DodamM!important;}
.navbar_custom, .nav > li > a:hover, .nav > li > a{font-size: 15px!important;font-family: lato!important;
font-weight: 600!important;}

.navbar_custom, .nav > li > a:hover, .nav > li > a:focus{color: #fafafa!important;
background-color: transparent!important;}


</style>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-76425287-1', 'auto');
  ga('send', 'pageview');

</script>

<title>카카오영어.com</title>
<script src="<?php echo base_url() ?>assets/faq_css/json2.js.download"></script>
<link href="<?php echo base_url() ?>assets/faq_css/grey.css" rel="stylesheet">
<script src="<?php echo base_url() ?>assets/faq_css/icheck.js.download"></script>

</head>
<body style="background-color: white;" cz-shortcut-listen="true">
		


		
	
		<div id="container-fluid">
			






<script src="./assets/faq_css/search.min.js.download"></script>
<script src="./assets/faq_css/menu.js.download"></script>
<script>


(function(a,b){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4)))window.location=b})(navigator.userAgent||navigator.vendor||window.opera,redirectUrl);


$(document).ready(function(){
	$('#modifyStudent').click(function(){
		var scrollY = $(window).scrollTop();
		$.ajax({
			url : makeUrl('../modifyStudent.view'),
			method : "GET",
			dataType : "html",
			success:function(msg){
				$('#light').html(msg);
				scheduleCell.showBox(scrollY, common.init(), true, true);
				common.init();
				$(function() { 
					$("#postcodify_search_button").postcodifyPopUp(); 
					});
			},
			error: function(request,status,error){
				alert(request.responseText);
			}
		});
	});
	
	$(".apply_test").each(function( i ) {
	    $(this).on("click", function(){
			var scrollY = $(window).scrollTop();
			$.ajax({
				url : makeUrl('../modifyStudent.view?mode=leveltest'),
				method : "GET",
				dataType : "html",
				success:function(msg){
					$('#light').html(msg);
					scheduleCell.showBox(scrollY, common.init(), true, true);
					common.init();
					$(function() { 
						$("#postcodify_search_button").postcodifyPopUp(); 
						});
					
					$('#light').css("height", "1030px");
				},
				error: function(request,status,error){
					//alert(request.responseText);
					var win = window.open("../naverLoginRequest.do?leveltest=true", "", "width=370, height=360, resizable=no, scrollbars=no, status=no;"); 
				}
			});
	    });
	  });	
	
	$(".view_leveltest").each(function( i ) {
	    $(this).on("click", function(){
			var scrollY = $(window).scrollTop();
			var lectureId = $(this).attr("data-id");
			var s = {};
			s["lectureId"] = lectureId;
			$.ajax({
				url : makeUrl('/m6/leveltestResult.view'),
				method : "GET",
				data : s,
				dataType : "html",
				success:function(msg){
					$('#light').html(msg);
					scheduleCell.showBox(scrollY, common.init(), true, true);
					
					if(!pc)
						$('#light').css("height", "1260px");
					else
						$('#light').css("height", "1560px");
					
					$(".toggleBtn").parent().toggleClass("open");
				},
				error: function(request,status,error){
					alert(request.responseText);
				}
			});
	    });
	  });		
	
	/*$(".apply_test").click(function() {

	});*/
	
	
});
</script>
	<style type="text/css">
	.teacher_box{
		min-height: 235px;
		box-shadow: 8px 8px 10px 2px #888888;
		border: 1px solid #c0c0c0;
		border-top: 4px solid #a70920;
		margin: 10px;
	}
	.mt25{
		margin-top: 25px;
	}
	.btn-profile-video{
		padding: 5px;
		margin: 10px 4px;
		font-size: 15px;
		font-weight: 600px;
		font-family: lato;
	}
	.btn-profile-video:hover{
		color: #ffffff;
    background-color: #ff003f;
	}
	.btn-profile-video{
		 background-color: #ff3366;
    color:#ffffff;
	    border-radius: 25px 25px 25px 25px!important;
        padding: 8px 20px 8px 20px;
        border:#ff3366;
	}

	.btn-schedule{
		padding: 5px;
		margin: 10px 4px;
	}
	.btn-schedule:hover{
    color: #ffffff;
    background-color: #ff003f;
}
.btn-schedule{

    background-color: #ff3366;
    color:#ffffff;
	    border-radius: 25px 25px 25px 25px!important;
        padding: 8px 20px 8px 20px;
        border:#ff3366;
}
.btn-schedule-white{

    background-color: #ffffff!important;
    color:#FF003F!important;
	    border-radius: 25px 25px 25px 25px!important;
        padding: 8px 20px 8px 20px;
        border:#ff3366;
        font-weight: 600;
        font-size: 15px;
        font-family: lato;
}

	.col-custom{
		    margin-top: 20px;
    margin-bottom: 20px;
    border: 2px solid rgba(30,30,30,0.03);
    box-shadow: 0 15px 30px 0 rgba(30,30,30,0.03);
    transition: all 0.6s;
	}

	.teachers_list{
		margin: 10px; box-shadow: 8px 8px 10px 2px #888888; 
	}

	.teacher_box1{
		border-bottom: 1px solid gainsboro; padding-bottom: 15px;
	}


	.teacher_img_col > img{
		border-radius:70px; 
	}

	.pad17{

		padding: 17px;
	}

	.pl20{
		padding-left: 20px;
	}
	.pl5{
		padding-left: 5px;
	}

	.pad10{
		padding: 10px;
	}

	.h200{
		
		height: 200px;
	}
	.h100p{
		height: 100%;
	}
	.h25p{
		height: 25%;
	}

	.h50p{
		height: 50%;
	}
	.pad5{
		padding: 5px;
	}


	#html5-watermark{
		display: none !important;
	}
	.text-left{
		text-align: left !important;
	}
		.control-label {
    margin-top: 20px!important;
}

.hdr1{
	    background: 0 0;
    border: 0;
    margin: 0;
    padding: 0;
    vertical-align: baseline;
    outline: 0;
}
.bg-clr{
	background-color: #75C7E4;
}
.fnt-white{
	color: #fff;
	font-size: 15px;
    font-weight: 500;
}
.fav-box{
	position:absolute; 
	right:0px; 
	font-size:20px; 
	top:10px; 
	color:#E74C3C;
}
.pl0{
	padding-left: 0px!important;
}
.pr0{
	padding-right: 0px!important;
}
.corner{
	border-radius: 50%!important;
}
@media (min-width: 320px) and (max-width: 767px){
	.sm-text{
		font-size: 17px!important;
	}
	.sm-panel{
		padding: 7px!important;
	}
	.btn-schedule{
		margin: 0px 0px!important;
		    padding: 5px 5px 5px 5px;
		     font-size: 12px!important;
	}
	.btn-profile-video{
		margin: 0px 0px!important;
		 padding: 5px 5px 5px 5px;
		 font-size: 12px!important;
	}
	.pl5{
		padding-left: 5px!important;
	}

}
@media (min-width: 768px) and (max-width: 2000px){
.pl150{
	padding-left: 150px;

}
}
</style>
		<header class="hdr1 bg-clr">
		<div class="container-fluid pl150">
		<div class="row">
			<div class="col-md-2">
		<a href="http://www.icecreamenglish.com"><img src="<?php echo base_url(); ?>/assets/images/icecream.png">
</a>		</div>
		<div class="col-md-6" >
			<nav class="navbar fnt-white" >
  <div class="container-fluid" style="float: right;">
    
    <ul class="nav navbar-nav" >
      <li class="active fnt-white"><a href="http://www.icecreamenglish.com" class="fnt-white">Home</a></li>
   
      <li class=""><a href="http://portal.icecreamenglish.com" class="fnt-white">Teachers</a></li>

      <li class=""><a href="http://www.icecreamenglish.com/packages/" class="fnt-white">Pricing</a></li>
     


    </ul>
  </div>
</nav>
  
			
		</div>
		<div class="col-md-4 ">
			<ul class="list-inline hidden-phone text-right">
										<li>
											<a  href="http://www.icecreamenglish.com/book-a-level-test/"   class="btn btn-info btn-schedule-white"><?php echo $this->lang->line('book_a_free_level_test'); ?></a>
										</li>
										<li><?php
				$role = get_user_role();
				$is_user_logged_in = is_user_logged_in();

				if (!$is_user_logged_in) {
					?>
											<a  href="<?php echo base_url() ?>student/login" class="btn btn-info html5lightbox btn-profile-video"><?php echo $this->lang->line('login'); ?></a>
											<?php
				}else{
					?>
												<a href="<?php echo base_url() ?>schedule" data-width="1000" data-height="800" class="btn btn-info html5lightbox btn-schedule"><?php echo $this->lang->line('dashboard'); ?></a>
												<?php
				}
				?>
										</li>
									</ul>
</div></div>
</div>
	</header>

<div id="light" class="white_content"></div>
	<div id="fade" class="black_overlay"></div>
<div id="wrap"> 

	<div id="container-fluid"> 

			
<!-- <div class="section">
	<img src="<?php echo base_url(); ?>assets/faq_css/m7_img_notice.jpg" width="1000" alt="">
</div>
			<div style="height:47px;"></div> -->
			





<link href="<?php echo base_url(); ?>assets/faq_css/grey(1).css" rel="stylesheet">
<script src="<?php echo base_url(); ?>assets/faq_css/icheck.js(1).download"></script>


<script>
	$(document).ready(function(){
		
		$('.search-method').iCheck({
			checkboxClass:'icheckbox_minimal-grey',
			radioClass:'iradio_minimal-grey',
			increaseArea:'50%'
		});
		$('#checkAll').change(function(){
			
			if($('#checkAll:checked').length == 1){
				$.each($('.manageCheck'), function(index, value){
					value.checked=true;
				})
			}
			else{
				$.each($('.manageCheck'), function(index, value){
					value.checked=false;
				})
			}
		})
	})
</script>

<style>
#notifyBoardTable thead tr th{
	height : 34px !important;
	border:none !important;
	padding:0 !important;
	text-align: center;
}
#notifyBoardTable tbody tr:last-of-type td{
	border: none !important;
}
#notifyBoardTable td{
	padding: 0 !important;
	height : 36px !important;
	border-top: none !important;
}
.search-method{
	float:left;
}
.search_check{
	float:left;
	overflow: hidden;
}
.iradio_minimal-grey{
	float:left;
}
</style>

<div style="height:9px;"></div>
			
		<!--  -->	<!--  -->
		<div style="overflow: hidden; height: 39px;">
			<div style="overflow: hidden;  width: 955px; margin: 0 auto;">
				
				
				
				
			</div>
			
			
		</div>
		
		<div style="height:20px;"></div>	
<table id="notifyBoardTable" style="text-align: center; margin: 0 auto; border: 1px solid #c0c0c0; width: 955px;" class="table">
	<thead style="width:970px; height:34px;">
		<tr style="height: 34px;">
			<th style="width: 36px;  background-image : url(&#39;../artifact/student_boardlist_header_check.png&#39;);">
				<input id="checkAll" class="align_vertical_center" type="checkbox" style="margin-top: 10.5px; margin-bottom: 10.5px;">
			</th>	
			<th style="width: 62px; background-image : url(&#39;../artifact/student_boardlist_header_no.png&#39;);"></th>
			<th style="width: 526px; background-image : url(&#39;../artifact/student_boardlist_header_title.png&#39;);"></th>
			<th style="width: 150px; background-image : url(&#39;../artifact/student_boardlist_header_writer.png&#39;);"></th>
			<th style="width: 94px; background-image : url(&#39;../artifact/student_boardlist_header_date.png&#39;);"></th>
			<th style="width: 87px; background-image : url(&#39;../artifact/student_boardlist_header_count.png&#39;);"></th>
		</tr>
	</thead>
	<tbody>
		
			
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="160" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">65</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;[정상수업안내] 8/15일 광복절은 '정상수업' 합니다.</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2018-08-09</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">184</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="159" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">64</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="color: rgb(224, 36, 45); margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;계속되는 최상위 레벨 선생님 영입 소식 !!</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2018-07-10</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">728</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="154" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">63</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;[정상수업공지] 6/6(수) 현충일과 6/13(수) 지방선거일은 정상수업 예정입니다.</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2018-06-01</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">274</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="153" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">62</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;[정상수업안내] 5/22(화) 부처님 오신날은 정상수업 합니다.</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2018-05-17</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">265</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="152" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">61</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="color: rgb(230, 127, 16); margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;[정상수업안내] 어린이날 대체휴일 5/7일(월) 정상수업 합니다.</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2018-04-27</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">413</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="151" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">60</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="color: rgb(201, 22, 129); margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;3/30일 금요일 부활절 부분휴강 안내드립니다.</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2018-03-27</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">444</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="150" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">59</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;[정상수업안내] 삼일절 정상수업 합니다.</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2018-02-26</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">452</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="148" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">58</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="color: rgb(193, 48, 201); margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;2018 2/15(목)~2/18(일) 설연휴 휴강일정 안내</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2018-02-12</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">377</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="145" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">57</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="color: rgb(235, 35, 75); margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;[휴강공지] 크리스마스 및 새해 첫 날 휴강 일정 안내</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2017-12-20</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">564</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="144" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">56</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;계속되는 상위 1% 선생님 영입소식 - Kaye &amp; Miz 선생님</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2017-10-22</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">1358</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="143" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">55</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="color: rgb(36, 179, 189); margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;추석 연휴기간 수업 안내드립니다.</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2017-09-21</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">644</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="142" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">54</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;최상위 레벨 선생님 두 분 영입 소식 - Teacher Lira and Juris</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2017-09-09</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">1073</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="141" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">53</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="color: rgb(20, 83, 209); margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;[정상수업안내] 8/15일 광복절 정상수업 합니다.</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2017-08-14</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">259</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="138" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">52</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="window.location=&quot;./notifyBoardView.view?boardId=138&amp;page=&amp;viewPerPage=&amp;searchMethod=&amp;searchText=&quot;; return false;">
					<p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">&nbsp;&nbsp;Miss A 선생님 Come Back 소식 !!</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 8.5px; margin-bottom: 8.5px;">2017-07-11</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 7.5px; margin-bottom: 7.5px;">810</p></td>
			</tr>
			
			<tr style="border: none;">
				<td style="width: 20px; text-align: center; border-bottom: none;">
					<input class="manageCheck align_vertical_center" type="checkbox" data-id="134" style="margin-top: 11.5px; margin-bottom: 11.5px;">
				</td>	
				<td style="border-bottom: 1px dotted rgb(264,208,197)"><p class="align_vertical_center" style="margin-top: 8px; margin-bottom: 8px;">51</p></td>
				<td style="text-align: left; cursor: pointer;border-bottom: 1px solid rgb(264,208,197);" onclick="">
					<p class="align_vertical_center" style="margin-top: 8.5px; margin-bottom: 8.5px;">&nbsp;&nbsp;계속되는 최상위 레벨 선생님 영입소식 - Nicole 선생님 영입</p>
				</td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 9px; margin-bottom: 9px;">운영자</p></td>
				<td style="border-bottom: 1px solid rgb(264,208,197);"><p class="align_vertical_center" style="font-size: 13px; margin-top: 10.5px; margin-bottom: 10.5px;">2017-06-04</p></td>
				<td style="border-bottom: 1px dotted rgb(264,208,197);"><p class="align_vertical_center" style="margin-top: 10px; margin-bottom: 10px;">812</p></td>
			</tr>
			
	</tbody>
</table>

		<div style="height:9px;"></div>
			
		<!--  -->	<!--  -->
		<div style="overflow: hidden; height: 39px;">
			<div style="overflow: hidden;  width: 955px; margin: 0 auto;">
				
				
				
				
			</div>
			
			
		</div>
		
		<div style="height:20px;"></div>
		
		
		


			






	</div>
	
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/faq_css/eModal.js.download"></script> 
<script type="text/javascript">
function privacy(){
	eModal.iframe({url:'../main/privacy.jsp', size:'lg',  loading:false, buttons:{close: true}, title: '개인정보취급방법'});
}
function rule(){
	eModal.iframe({url:'../main/rule.jsp', size:'lg', loading:false, buttons:{ close: false }, title: '이용약관'});
}
</script>
<style>
#divtop {
	position:fixed; _position:absolute; bottom:10px; right:25px;
	border:none; 
	width:51px;
	z-index:10;
}
#divtop .go {	
	width:51px; min-height:51px;  
	-moz-border-radius:10px;  /* firefox's individual border radius properties */	
	-webkit-border-radius:10px; /* webkit's individual border radius properties */
	border-radius:10px;
	background-color:#272727;
	color:white;
	margin:0 0 5px 0;
	padding:15px;
	text-align:center; 
	cursor:pointer;
} 
#divtop .go span { color:white; font-weight:bold;cursor:pointer;}
#gotop { 
	cursor:pointer;
	display:block; position:relative; 
	background:url(../images/ui.totop.png) no-repeat left top;
	width:51px;
	height:51px;
}  
</style>
<script type="text/javascript">
$(function(){

	$("div.gotop").fadeIn("slow");	

	$(window).scroll(function(){
		setTimeout(scroll_top, 200);//화살표가 반응하여 생기는 시간
	});
	$("#gotop").hover(function(){
		//$(this).css("background-color","#307ad5");
	}, function(){
		//$(this).css("background","url(../images/ui.totop.png) no-repeat left -51px;");
		scroll_top()
	}) 
	$("#gotop").click(function(){
		$("html, body").animate({ scrollTop: 0 }, 0);//화살표 클릭시 화면 스크롤 속도
			return false;
    });
	$("#gohome").click(function(){
		location.href="/";
    });
	$("#goteacher").click(function(){
		location.href="/m3/match.view?sort=TeacherMatch&course=TypeEasy&title=&month=3&period=&duration=";
    });
	$("#gonotice").click(function(){
		location.href="/m7/notifyBoardList.view";
    });
})
function scroll_top(){
	if($(window).scrollTop()<=1) {
		//$("#divtop").fadeOut(400);
	}
	else {
		//$("#divtop").fadeIn(600);
	}
}
</script>

</div><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/faq_css/search.css"></body><loom-container id="lo-engage-ext-container"><loom-shadow classname="resolved"></loom-shadow></loom-container></html>

