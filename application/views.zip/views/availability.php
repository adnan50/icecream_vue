
<div class="">
	<div id="set_availabilty"></div>
</div>


<div>
	
	<button class="btn btn-primary btn-lg" id="save_availability">Save</button>
</div>


<style type="text/css">
	.error{
		color: red; 
	}
</style>




