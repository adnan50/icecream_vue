<footer>
	<div class="footer_inner clearfix">
		<div class="footer_top_holder">
			<div class="footer_top_border" style="background-color: #FF3366;height: 1px;"></div>
			<div class="footer_top">
				<div class="container">
					<div class="container_inner">
						<div class="widget widget_text" id="text-4">
							<div class="textwidget">
								<div class="contact">
									<p class="tel-title" style="color: #ffffff; font-weight: 600px; font-size: 20pxfont-family: lato;">电话咨询</p>
									<h3 class="tel-number" style="font-size: 32px;color:#fff;  font-family: lato; font-size: 45px;font-weight: 800;">1010-0888</h3>
									<p class="tel-online" style="color: #ffffff; font-weight: 600px; font-size: 15px;font-family: lato;">上午 08:00 ~ 晚上 21:00</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer_bottom_holder">
			<div class="container">
				<div class="container_inner">
					<div class="footer_bottom">
						<div class="textwidget">
							
						</div>
						<div class="textwidget">
							<p style="line-height:2.2 font-size: 12px;font-family: lato;font-weight: 600;">©2019 Icecream </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>

