<head>
	<meta content="text/html; charset=utf-8" http-equiv="content-type">
	<meta charset="UTF-8">
	<title>ICE CREAM ENGLISH</title>
	<meta content="width=device-width,initial-scale=1,user-scalable=no" name="viewport">
	<link href='http://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900,300italic,400italic,700italic|Roboto+Condensed:100,200,300,400,500,600,700,800,900,300italic,400italic,700italic|Lato:100,200,300,400,500,600,700,800,900,300italic,400italic,700italic&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
	<style type="text/css">
	img.wp-smiley,
	img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 .07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}

	.page-id-16872.disabled_footer_top .footer_top_holder, .page-id-16872.disabled_footer_bottom .footer_bottom_holder { display: none;}
	.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}
	.wpb_animate_when_almost_visible { opacity: 1; }
</style>

<link href='<?php echo base_url() ?>assets/apps/css/stylesheet.min.css' id='stylesheet-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url() ?>assets/apps/css/style_dynamic.css' id='style_dynamic-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url() ?>assets/apps/css/responsive.min.css' id='responsive-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url() ?>assets/apps/css/style_dynamic_responsive.css' id='style_dynamic_responsive-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url() ?>assets/apps/css/js_composer.min.css' id='js_composer_front-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url() ?>assets/apps/css/custom_css.css' id='custom_css-css' media='all' rel='stylesheet' type='text/css'>

<script src='<?php echo base_url() ?>assets/apps/scripts/jquery1.js' type='text/javascript'>
</script>
</head>