<header class=" scroll_header_top_area light regular page_header">
	<div class="header_inner clearfix">
		<div class="header_top_bottom_holder">
			<div class="header_bottom clearfix" style=' background-color:rgba(117, 199, 228, 1);'>
				<div class="container">
					<div class="container_inner clearfix">
						<div class="header_inner_left">
							<div class="mobile_menu_button">
								<span><i class="qode_icon_font_awesome fa fa-bars"></i></span>
							</div>
							<div class="logo_wrapper">
								<div class="q_logo">
									<a href="http://www.icecreamenglish.com/" itemprop="url"><img alt="Logo" class="normal" itemprop="image" src="<?php echo base_url() ?>assets/images/layout/imageedit_9_4207182567.png"> <img alt="Logo" class="light" itemprop="image" src="<?php echo base_url() ?>assets/images/layout/imageedit_9_4207182567.png"> <img alt="Logo" class="dark" itemprop="image" src="<?php echo base_url() ?>assets/images/layout/icecream.png"> <img alt="Logo" class="sticky" itemprop="image" src="<?php echo base_url() ?>assets/images/layout/white.png"> <img alt="Logo" class="mobile" itemprop="image" src="<?php echo base_url() ?>assets/images/layout/light_fuchsia.png"></a>
								</div>
							</div>
						</div>
						<div class="header_inner_right">
							<div class="side_menu_button_wrapper right">
								<div class="side_menu_button"></div>
							</div>
						</div>
						<nav class="main_menu drop_down right">
							<ul class="" id="menu-main-menu">
								<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home narrow" id="nav-menu-item-16828">
									<a class="" href="http://www.icecreamenglish.com/"><i class="menu_icon blank fa"></i><span>Home</span><span class="plus"></span></a>
								</li>
								<li class="menu-item menu-item-type-post_type menu-item-object-page narrow" id="nav-menu-item-16159">
									<a class="" href="http://www.icecreamenglish.com/%EB%A0%88%EB%B2%A8%ED%85%8C%EC%8A%A4%ED%8A%B8/"><i class="menu_icon blank fa"></i><span>레벨테스트</span><span class="plus"></span></a>
								</li>
								<li class="menu-item menu-item-type-post_type menu-item-object-page narrow" id="nav-menu-item-16164">
									<a class="" href="http://www.icecreamenglish.com/%EC%88%98%EA%B0%95%EC%8B%A0%EC%B2%AD/"><i class="menu_icon blank fa"></i><span>수강신청</span><span class="plus"></span></a>
								</li>
								<li class="menu-item menu-item-type-post_type menu-item-object-page narrow" id="nav-menu-item-16161">
									<a class="" href="http://www.icecreamenglish.com/%EA%B3%A0%EA%B0%9D-%EC%83%81%EB%8B%B4/"><i class="menu_icon blank fa"></i><span>고객 상담</span><span class="plus"></span></a>
								</li>
								<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children has_sub narrow" id="nav-menu-item-16162">
									<a class="" href="http://www.icecreamenglish.com/%EA%B3%A0%EA%B0%9D-%EC%84%BC%ED%84%B0/"><i class="menu_icon blank fa"></i><span>고객 센터</span><span class="plus"></span></a>
									<div class="second">
										<div class="inner">
											<ul>
												<li class="menu-item menu-item-type-post_type menu-item-object-page" id="nav-menu-item-3067">
													<a class="" href="http://www.icecreamenglish.com/faq-2/"><i class="menu_icon blank fa"></i><span>FAQ</span><span class="plus"></span></a>
												</li>
												<li class="menu-item menu-item-type-post_type menu-item-object-page" id="nav-menu-item-16163">
													<a class="" href="http://www.icecreamenglish.com/%EA%B3%B5%EC%A7%80%EC%82%AC%ED%95%AD/"><i class="menu_icon blank fa"></i><span>공지사항</span><span class="plus"></span></a>
												</li>
												<li class="menu-item menu-item-type-post_type menu-item-object-page" id="nav-menu-item-16160">
													<a class="" href="http://www.icecreamenglish.com/%EA%B5%90%EC%9E%AC/"><i class="menu_icon blank fa"></i><span>교재</span><span class="plus"></span></a>
												</li>
											</ul>
										</div>
									</div>
								</li>
							</ul>
						</nav>
						<nav class="mobile_menu">
							<ul class="" id="menu-main-menu-1">
								<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home" id="mobile-menu-item-16828">
									<a class="" href="http://www.icecreamenglish.com/"><span>Home</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
								</li>
								<li class="menu-item menu-item-type-post_type menu-item-object-page" id="mobile-menu-item-16159">
									<a class="" href="http://www.icecreamenglish.com/%EB%A0%88%EB%B2%A8%ED%85%8C%EC%8A%A4%ED%8A%B8/"><span>레벨테스트</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
								</li>
								<li class="menu-item menu-item-type-post_type menu-item-object-page" id="mobile-menu-item-16164">
									<a class="" href="http://www.icecreamenglish.com/%EC%88%98%EA%B0%95%EC%8B%A0%EC%B2%AD/"><span>수강신청</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
								</li>
								<li class="menu-item menu-item-type-post_type menu-item-object-page" id="mobile-menu-item-16161">
									<a class="" href="http://www.icecreamenglish.com/%EA%B3%A0%EA%B0%9D-%EC%83%81%EB%8B%B4/"><span>고객 상담</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
								</li>
								<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children has_sub" id="mobile-menu-item-16162">
									<a class="" href="http://www.icecreamenglish.com/%EA%B3%A0%EA%B0%9D-%EC%84%BC%ED%84%B0/"><span>고객 센터</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
									<ul class="sub_menu">
										<li class="menu-item menu-item-type-post_type menu-item-object-page" id="mobile-menu-item-3067">
											<a class="" href="http://www.icecreamenglish.com/faq-2/"><span>FAQ</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
										</li>
										<li class="menu-item menu-item-type-post_type menu-item-object-page" id="mobile-menu-item-16163">
											<a class="" href="http://www.icecreamenglish.com/%EA%B3%B5%EC%A7%80%EC%82%AC%ED%95%AD/"><span>공지사항</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
										</li>
										<li class="menu-item menu-item-type-post_type menu-item-object-page" id="mobile-menu-item-16160">
											<a class="" href="http://www.icecreamenglish.com/%EA%B5%90%EC%9E%AC/"><span>교재</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
										</li>
									</ul>
								</li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>

 <?php //wp_head(); ?>